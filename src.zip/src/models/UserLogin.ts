interface UserLogin {
    id: number;
    nome: string;
    usuario: string;
    foto: string;
    senha: string;
    token: string;
    tipoUser: string;
}

export default UserLogin;