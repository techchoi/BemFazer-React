interface User {
id: number;
nome: string;
email: string;
senha: string;
foto: string;
tipoUser: string;
}

export default User;