interface Categoria {
  id: number;
  tipo: string;
}

export default Categoria;
